# SKILL: 54c071a6-082b-4205-8c42-a50aa216bc9f

## Overview

**Domain**: aiops
**User Intent**: Reduce downtime and manual operational overhead by automatically detecting and recovering from Kubernetes pod failures, improving service reliability and availability while freeing the operations team from repetitive manual interventions
**Capabilities**: Kubernetes API integration for real-time pod status monitoring, Pod health status detection (CrashLoopBackOff, ImagePullBackOff, OOMKilled, etc.), Automated pod restart execution via kubectl/K8s API, Intelligent retry logic with exponential backoff to prevent restart loops, State tracking for restart attempts and failure patterns, Alert and notification system (Slack, PagerDuty, email) for restart actions and persistent failures, Resource usage monitoring to detect OOM or resource constraint issues, Audit logging and action history for compliance and debugging, Integration with observability platforms (Prometheus, Grafana, Datadog), Escalation workflows for failures that persist after N restart attempts

## Generated Information

- **Session ID**: 54c071a6-082b-4205-8c42-a50aa216bc9f
- **Output Type**: skill
- **Language**: typescript
- **Quality Tier**: simple
- **Generated**: 2026-02-12T13:46:07.754Z

## Structure

This package contains all the artifacts generated for your agent:

- `src/` - Source code
- `tests/` - Test files
- `docs/` - Documentation
- `config/` - Configuration files
- `SETUP.md` - Installation and setup instructions
- `README.md` - This file

## Quick Start

See `SETUP.md` for detailed installation instructions.

## Design Decisions

### Deployment Model
**Decision**: In-cluster deployment as Kubernetes Deployment with leader election
**Reasoning**: Running in-cluster provides lowest latency (<50ms to K8s API), simplifies authentication via ServiceAccount, enables automatic pod discovery, and aligns with K8s native patterns. Leader election ensures only one active instance for state consistency while maintaining high availability with multiple replicas.

### Event Detection Method
**Decision**: Kubernetes Watch API with fallback polling
**Reasoning**: Watch API provides real-time event stream with millisecond latency, enabling <60s alert latency goal. More efficient than polling (reduces API load by 95%). Fallback polling ensures resilience if watch connection drops. Bookmark tracking prevents event loss during reconnections.

### State Storage
**Decision**: Redis with TTL for short-term state, audit log for long-term history
**Reasoning**: Redis provides <10ms lookup latency critical for fast decision making. TTL automatically cleans up stale state (1-hour windows). Optional persistence allows recovery but not required since state is short-lived. Audit log provides durable history for compliance. Fallback to in-memory degraded mode if Redis unavailable.

### Circuit Breaker Implementation
**Decision**: Custom sliding window circuit breaker with 5 restarts/hour threshold
**Reasoning**: Aligns directly with success criteria (no pod restarted >5 times in 1 hour). Sliding window more accurate than fixed window (prevents edge case gaming). Exponential cooldown prevents rapid state flapping. Custom implementation allows domain-specific logic (e.g., different thresholds per failure type).

### Concurrency Model
**Decision**: Asyncio with async/await for I/O-bound operations
**Reasoning**: Watch streams are I/O-bound (waiting for events). Asyncio allows monitoring hundreds of namespaces with single-digit CPU cores. Lower memory footprint than threading (1/10th per task). Native Python 3.11+ support. Excellent library support (aiohttp, async redis, kubernetes async client).

### Metrics Export
**Decision**: Prometheus format with /metrics endpoint and push to Datadog
**Reasoning**: Prometheus is de facto standard for K8s monitoring. Pull-based model simplifies networking (no egress config). Grafana has excellent Prometheus integration. Push to Datadog optional for teams using Datadog APM. Custom metrics for MTTR, recovery rate directly support success criteria measurement.

### Alert Routing
**Decision**: Severity-based multi-channel with rate limiting
**Reasoning**: Different failure types require different urgency. Info alerts (successful restart) to Slack, Critical alerts (circuit breaker open) to PagerDuty. Rate limiting prevents alert fatigue (max 1 alert/pod/5min for same issue). Reduces false positive impact while maintaining visibility.

### Restart Mechanism
**Decision**: Pod deletion (not scale to 0) via Kubernetes API
**Reasoning**: Pod deletion triggers controller (Deployment/StatefulSet) to create new pod with fresh state. Leverages K8s self-healing. Respects pod disruption budgets. Maintains desired replica count. More reliable than exec-based restart (works for all failure types).

### Resource Monitoring
**Decision**: Kubernetes Metrics API with Prometheus query fallback
**Reasoning**: Metrics API provides standard interface for resource usage (CPU, memory). Lower latency than querying Prometheus. Fallback to Prometheus for historical analysis. Enables OOM detection and capacity recommendations. Direct correlation with K8s pod status.

### Configuration Management
**Decision**: ConfigMap with hot reload and Pydantic validation
**Reasoning**: ConfigMap is K8s native, no external dependency. Hot reload allows tuning without restart. Pydantic provides type safety and validation. Schema-driven documentation. Version control friendly (YAML). Secrets for sensitive data (API keys).


## Success Criteria

1. Mean Time To Recovery (MTTR) reduced by 60-80% for pod failures (from manual 10-15min to automated 30-60s)
2. Auto-recovery success rate >85% (pods successfully restarted and stable within 5 minutes)
3. Reduction in after-hours on-call incidents by 40-50% due to automated remediation
4. Zero restart loops - no pod restarted more than 5 times in 1 hour without human escalation
5. Pod availability improved to 99.9%+ for services under agent management
6. False positive rate <5% (unnecessary restarts when pod would have recovered naturally)
7. Alert notification latency <60 seconds from failure detection to team notification
8. 100% audit trail - all restart actions logged with timestamp, pod details, and outcome
9. Integration with existing monitoring dashboards showing auto-remediation metrics
10. Capacity insights - identification of resource-constrained pods leading to proactive scaling decisions

## Support

Generated by Synthient Agent-Builder Platform.

For issues or questions about the generated agent, refer to the documentation or contact your administrator.
