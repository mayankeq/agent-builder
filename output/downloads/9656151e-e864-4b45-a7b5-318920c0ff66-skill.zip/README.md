# SKILL: 9656151e-e864-4b45-a7b5-318920c0ff66

## Overview

**Domain**: aiops
**User Intent**: Build an intelligent AIOps agent to reduce operational toil, minimize incident response time, and prevent outages in a Kubernetes environment. The agent should act as a force multiplier for the SRE team by automating routine remediation, learning from past incidents, and providing intelligent alerting that respects production criticality. The ultimate goal is to shift from reactive firefighting to proactive incident prevention while maintaining system reliability and reducing on-call burden.
**Capabilities**: Real-time Kubernetes pod health monitoring via API and Prometheus metrics, Multi-source log correlation across Datadog, Kubernetes events, and application logs, Safe auto-remediation execution (pod restarts, horizontal scaling, config rollbacks), Historical incident pattern matching and resolution recommendation from PostgreSQL database, Intelligent alert routing and escalation via PagerDuty API, Tribal knowledge extraction from Slack #sre channel and runbook repositories, Environment-aware severity classification (prod-critical vs dev-warning), Time-series anomaly detection for capacity forecasting, Automated blameless postmortem generation with timeline reconstruction, Root cause analysis through distributed trace correlation, Safe rollback and canary deployment coordination

## Generated Information

- **Session ID**: 9656151e-e864-4b45-a7b5-318920c0ff66
- **Output Type**: skill
- **Language**: typescript
- **Quality Tier**: simple
- **Generated**: 2026-02-13T02:58:46.967Z

## Structure

This package contains all the artifacts generated for your agent:

- `src/` - Source code
- `tests/` - Test files
- `docs/` - Documentation
- `config/` - Configuration files
- `SETUP.md` - Installation and setup instructions
- `README.md` - This file

## Quick Start

See `SETUP.md` for detailed installation instructions.

## Design Decisions

### Architecture Pattern
**Decision**: Event-driven microservices with central orchestration (IncidentManager)
**Reasoning**: Allows independent scaling of monitoring, remediation, and learning services. Event-driven enables loose coupling and async processing. Central orchestrator maintains incident lifecycle consistency while allowing specialized services to scale independently.

### Remediation Safety Model
**Decision**: Multi-layered safety with explicit approval workflow for high-risk actions
**Reasoning**: Safety is paramount (zero incorrect remediations required). Pre-flight checks validate environment. SafetyChecker enforces allow-lists and environment constraints. High-risk actions (prod DB restarts, large-scale changes) require manual approval. Dry-run mode allows testing without execution. All actions logged for audit.

### Anomaly Detection Approach
**Decision**: Hybrid: Statistical methods (z-score, IQR) for real-time + Prophet for capacity forecasting
**Reasoning**: Statistical methods provide low-latency detection (<1s) for threshold breaches. Prophet handles seasonality and trends for 4-hour capacity predictions. Both are interpretable (important for SRE trust). Avoids complex deep learning (harder to explain, needs more data, slower inference).

### Storage Strategy
**Decision**: PostgreSQL for durable data (incidents, runbooks), Redis for ephemeral state, ChromaDB for embeddings
**Reasoning**: PostgreSQL provides ACID guarantees for incident history, supports JSONB for flexible schemas, has full-text search. Redis offers low-latency for circuit breakers, rate limiting, caching. ChromaDB specialized for vector similarity search. Separation by data characteristics optimizes performance and cost.

### Event Bus Implementation
**Decision**: Redis Pub/Sub for initial implementation, with option to migrate to RabbitMQ/Kafka for scale
**Reasoning**: Redis Pub/Sub is simple, low-latency, already deployed for state. Sufficient for initial scale (<1000 events/sec). At-least-once delivery via message persistence. Easy migration path to RabbitMQ (AMQP) or Kafka (high-throughput) if event volume grows.

### Semantic Search Technology
**Decision**: sentence-transformers with all-MiniLM-L6-v2 model + ChromaDB
**Reasoning**: Pre-trained sentence-transformers provide good quality without training. all-MiniLM-L6-v2 balances accuracy and speed (fast inference for <100ms runbook retrieval). ChromaDB is lightweight, easy to deploy, sufficient for ~1000 runbooks. Cosine similarity for ranking.

### Remediation Execution Model
**Decision**: Async task queue (Celery) with Redis backend for remediation jobs
**Reasoning**: Remediations can be long-running (pod restarts take 30-60s). Celery provides retries, task routing, worker scaling. Decouples execution from decision-making. Supports scheduled tasks (e.g., gradual capacity scaling). Redis backend is fast and already deployed.

### Alert Aggregation Window
**Decision**: 60-second correlation window with exponential backoff for repeat alerts
**Reasoning**: 60s aligns with MTTD requirement. Allows time to correlate related events (cascading failures). Exponential backoff (1min → 5min → 15min) prevents alert storms while ensuring critical alerts aren't suppressed too long. Configurable per service criticality.

### Historical Data Retention
**Decision**: Full incident data retained indefinitely, time-series metrics follow Prometheus retention (30 days)
**Reasoning**: Incident data is small (<100MB/year), valuable for learning, compliance. Full retention enables long-term pattern analysis. Prometheus metrics (high-volume) follow existing retention policy. Can archive to cold storage (S3) after 1 year if needed.

### Deployment Model
**Decision**: Kubernetes Deployment with multiple replicas for high availability
**Reasoning**: Agent must be highly available to meet MTTD requirements. Multiple replicas provide failover. StatefulSet not needed (state in Redis/PostgreSQL). Horizontal Pod Autoscaler scales monitoring workers based on load. Leader election for singleton tasks (model training).


## Success Criteria

1. Mean Time to Detect (MTTD) < 60 seconds for production-critical issues
2. Mean Time to Resolve (MTTR) reduced by 50% for common incident types (baseline from historical data)
3. Auto-remediation success rate > 80% for Tier 1/2 actions without human intervention
4. False positive alert rate < 5% (measured by on-call engineer feedback)
5. Capacity prediction accuracy: detect resource constraints 4+ hours before exhaustion with <10% false positive rate
6. Zero incidents caused by incorrect auto-remediation (safety-critical metric)
7. On-call page reduction by 40% through intelligent alert filtering and auto-resolution
8. Postmortem generation time reduced from 2-4 hours to <15 minutes for timeline reconstruction
9. Incident correlation accuracy > 90% (correctly group related failures)
10. Runbook retrieval relevance: top-3 recommended runbooks contain solution in 85% of cases
11. Alert context richness: 95% of pages include runbook link, relevant logs, and similar past incidents

## Support

Generated by Synthient Agent-Builder Platform.

For issues or questions about the generated agent, refer to the documentation or contact your administrator.
