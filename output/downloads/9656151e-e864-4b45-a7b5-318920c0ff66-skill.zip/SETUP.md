# Skill Setup Instructions

## Installation

This is a Claude Code skill. To install:

1. **Extract the ZIP file**
   ```bash
   unzip 9656151e-e864-4b45-a7b5-318920c0ff66-skill.zip -d my-skill
   cd my-skill
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Build the skill** (TypeScript only)
   ```bash
   npm run build
   ```

4. **Deploy to Claude Code**
   ```bash
   cp -r . ~/.claude/skills/$(basename $PWD)
   ```

5. **Verify installation**
   - Open Claude Code CLI
   - The skill should appear in your available skills list

## Usage

Invoke the skill in Claude Code using its skill invocation command.

## Configuration

Check the skill.yaml file for configuration options.

## Troubleshooting

- **Skill not appearing**: Restart Claude Code CLI
- **Dependencies missing**: Re-run install commands
- **Build errors**: Check for TypeScript/Python version compatibility
